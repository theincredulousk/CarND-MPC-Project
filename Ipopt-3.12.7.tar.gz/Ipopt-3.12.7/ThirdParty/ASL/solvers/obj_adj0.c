#include "asl.h"

 void
obj_adj_ASL(ASL *asl)
{} /* do nothing */

